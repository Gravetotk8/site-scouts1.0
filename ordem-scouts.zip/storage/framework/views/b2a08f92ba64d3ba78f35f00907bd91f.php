<?php $__env->startSection('conteudo'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <h1 class="mt-5">Bem-vindo a Scouts Info</h1>
           
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ordem-scouts\resources\views/home.blade.php ENDPATH**/ ?>