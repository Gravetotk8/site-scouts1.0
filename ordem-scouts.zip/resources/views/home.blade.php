@extends('layout')

@section('conteudo')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <h1 class="mt-5">Bem-vindo a Scouts Info</h1>
           
        </div>
    </div>
</div>

@endsection